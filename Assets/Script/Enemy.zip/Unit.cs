using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : GameCharacter
{
    public bool e_active;
    public float active_timer;
    public float active_time = 1.5f;
    public GameObject Player;
    public GameObject Destroy_effect;
    Color color;
    public bool sentinal;
    public GameObject DNP;
    public ProgressBarPro progressBar;
    public ActionRecord record;
    private void Awake()
    {
        // E_Status = this.transform.parent.gameObject.GetComponent<Enemy_status>();
        record = GameObject.Find("GameSystem").GetComponent<Record>().ActionRecord;
        DNP = GameObject.Find("DemoManager");
    }
    void Start()
    {
        prefab = Resources.Load("Ef") as GameObject;
        color = this.gameObject.transform.GetChild(1).GetComponent<SpriteRenderer>().color;
        progressBar = GetComponent<Enemy_UI>().GetBar();
        progressBar.SetBarColor(Color.red);
    }
    void Update()
    {
        if (Player == null && GameObject.FindGameObjectWithTag("Player"))
        {
            Player = GameObject.FindGameObjectWithTag("Player");
        }
        if (!e_active)
        {
            active_enemy();
        }
       /* if (Player != null)
        {
            if (transform.position.x - Player.transform.position.x >= 0)
            {
                if (direction == -1)
                {
                    direction_change();
                    direction = -1;
                }
            }
            else
            {
                if (direction == 1)
                {
                    direction_change();
                    direction = 1;
                }
            }
        }*/

        }
    void active_enemy()
    {
        if (active_timer < active_time)
        {
            color.a = active_timer;
            this.gameObject.transform.GetChild(1).GetComponent<SpriteRenderer>().color = color;
            active_timer += Time.deltaTime;
        }
        else
        {
            color.a = 1;
            this.gameObject.transform.GetChild(1).GetComponent<SpriteRenderer>().color = color;
            e_active = true;
        }
    }
    public GameObject prefab;
    GameObject Ins;
    void OnTriggerEnter2D(Collider2D other)
    {
        if (e_active)
        {
            if (other.tag == "Bullet")
            {
                Debug.Log("������ ����");
                this.gameObject.GetComponent<Enemy_UI>().Hit();
               // Ins=Instantiate(prefab);
                //Ins.transform.position = this.transform.position;
                character_lose_health(other.GetComponent<Bullet>().Damge,DNP,other.gameObject.transform);
                sentinal = true;
                progressBar.SetValue(Health_point, max_hp, true);
                other.GetComponent<Bullet>().DestroyBullet();
                record.Damge += other.GetComponent<Bullet>().Damge;
            }
        }
    }
    public void HpCheack()
    {
        if (Health_point <= 0)
        {
            Enemy_status e = GetComponent<Enemy_status>();
            int Total = e.get_money();
            Inventory.Money += Total;
            Font_manager.DN.SpawnNumber(9, Total, this.gameObject.transform);
            Debug.Log("���� �� " + Inventory.Money);
            this.gameObject.GetComponent<Enemy_UI>().DestoryUI();
            Instantiate(Destroy_effect, this.transform.position, Quaternion.identity);
            Destroy(this.gameObject);

        }
    }

}

