using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class E_05_AI : MonoBehaviour
{
    Vector2 dir;
    private Quaternion rotation;
    Enemy_status E_Status;
    public float attack_time;
    bool attack_status;
    public bool can_attack;
    public float bullet_size;
    float attack_weight;
    Unit unit;
    GameObject Player;
    bool sentinal;
    float move_distance;
    public float move_distance_max;
    public float enemy_size_x;
    public float enemy_size_y;
    public float moving_buffer;
    float moving_weight;
    public float range_distance;
    bool move_corutine_check;
    bool idle_corutine_check;
    bool moving_status;
    public float idle_time;
    public float random_num;
    public float random_num2;
    public Vector2 sentinal_size;
    private Collider2D sensitive;
    public int upvector = 1;
    Animator e_ani;
    public int wall_bound = 1;
    float t;
    // Start is called before the first frame update
    void Start()
    {
        random_num = Random.Range(0, 1.0f);
        random_num2 = Random.Range(0, 1.0f);
        Player = GameObject.FindGameObjectWithTag("Player");
        unit = this.GetComponent<Unit>();
        attack_status = true;
        e_ani = this.transform.GetChild(1).GetComponent<Animator>();
        E_Status = this.gameObject.GetComponent<Enemy_status>();
        E_Status.set_layout(4);

        unit.max_hp = E_Status.get_max_hp();
        unit.Health_point = E_Status.get_hp();
        unit.Defense_point = E_Status.get_defense_point();
        unit.move_speed = E_Status.get_speed();
        unit.Attack_point = E_Status.get_atk();
    }
    void ray_to_player()
    {
        float length = Mathf.Log(Mathf.Pow(18, 2) + Mathf.Pow(28, 2)) * 2;
        var dir_dist = Mathf.Log(Mathf.Pow(dir.x, 2) + (Mathf.Pow(dir.y, 2)));
        Debug.DrawLine(transform.position, Player.transform.position.normalized * dir_dist, Color.red);
        // Debug.DrawLine(transform.position - Vector3.up * (bullet_size / 2), Player.transform.position.normalized * range_distance, Color.red);
        // var ray1= Physics2D.Raycast(transform.position+Vector3.up*(bullet_size/2), dir, length, LayerMask.GetMask("platform_can't_pass"));
        // var ray2 = Physics2D.Raycast(transform.position - Vector3.up * (bullet_size / 2), dir, length, LayerMask.GetMask("platform_can't_pass"));
        var ray = Physics2D.Raycast(transform.position, dir, length, LayerMask.GetMask("platform_can't_pass"));
        var ray2 = Physics2D.Raycast(transform.position, dir, length, LayerMask.GetMask("platform_can_pass"));
        if (ray.collider != null)
        {
    
            can_attack = false;
        }
        else
        {
   
            can_attack = true;
        }
    }
    // Update is called once per frame
    void Update()
    {
        brain();
    }
    void brain()//ai ����
    {
        if (unit.Health_point > 0)
        {
            if (t >= 1.3f)
            {
                t = 0;
             random_num = Random.Range(0, 1.0f);
                random_num2 = Random.Range(0, 1.0f);
        
            }
            else
            {
                t += Time.deltaTime;
            }
            dir = Player.transform.position - this.transform.position;
            var dir_dist = Mathf.Log(Mathf.Pow(dir.x, 2) + (Mathf.Pow(dir.y, 2)));
            ray_to_player();
            

            /*if (dir_dist<range_distance||unit.sentinal)//���� �ȸ���+�����Ÿ���
            {
                attack_ai_0();
            }
            else
            {*/

                if (move_corutine_check)
                {
                    if (!moving_status)
                        StartCoroutine("move");//�̵�����
                }
                else
                {
                    if (!idle_corutine_check)
                        StartCoroutine("idle");//���  ����
                }
                if (moving_status)
                {
                    move_ai_0();
                }
           // }
        }
        else
        {
            die();
        }
    }

    void die()
    {
        unit.HpCheack();

    }














    void move_ai_0()
    {
        
        
       /* if (random_num > 0.5)
        {
            if (unit.direction == -1)
            {
                
                unit.direction_change_spr();
            }
           
            
        }
        else
        {
            if (unit.direction == 1)
            {
                unit.direction_change_spr();
            }
       
        }*/
        transform.Translate(Vector3.left * unit.direction * unit.move_speed * Time.deltaTime);

            transform.Translate(Vector3.up * unit.move_speed*upvector* Time.deltaTime);

       
     
        move_distance += unit.move_speed * Time.deltaTime;
        //���鿡 ����ĳ��Ʈ�� ������
        Debug.DrawLine(transform.position, transform.position - (new Vector3(0.2f, 0, 0) + new Vector3(enemy_size_x / 2, 0, 0)) * unit.direction, Color.blue);
        //Debug.DrawLine(transform.position, transform.position - (new Vector3(0, 0,2, 0) + new Vector3(enemy_size_y / 2, 0, 0)) * unit.direction*, Color.blue);
        //Debug.DrawLine(transform.position, transform.position - (new Vector3(0.2f, 0, 0) + new Vector3(enemy_size_y / 2, 0, 0)) * unit.direction, Color.blue);
        var wall_ray = Physics2D.Raycast(transform.position, Vector3.left * unit.direction, enemy_size_x / 2 + 0.2f, LayerMask.GetMask("platform_can't_pass"));
        var bottom_ray = Physics2D.Raycast(transform.position, Vector3.down * unit.direction, enemy_size_y / 2 + 0.2f, LayerMask.GetMask("platform_can't_pass"));
        var top_ray = Physics2D.Raycast(transform.position, Vector3.up * unit.direction, enemy_size_y / 2 + 0.2f, LayerMask.GetMask("platform_can't_pass"));
        if (wall_ray.collider != null)
        {
            unit.direction_change_spr();
            Debug.Log("col");
        }
        if (bottom_ray.collider != null)
        {
            upvector *= -1;
            Debug.Log("col");
        }
        if (top_ray.collider != null)
        {
            upvector *= -1;
            Debug.Log("col");
        }

        }
    void attack_ai_0()
    {
        e_ani.SetBool("move", true);
        transform.Translate(dir.normalized * unit.move_speed * Time.deltaTime);
    }


    IEnumerator move()
    {
        var wait = new WaitForSeconds(moving_buffer + moving_weight);
        e_ani.SetBool("move", true);
        moving_status = true;
        yield return wait;
        move_corutine_check = false;
        e_ani.SetBool("move", false);
        moving_status = false;
        moving_weight = Random.Range(-1, 1);
    }
    IEnumerator idle()
    {
       
        var wait = new WaitForSeconds(idle_time);
        e_ani.SetBool("move", false);

        idle_corutine_check = true;
        yield return wait;
        move_corutine_check = true;
        idle_corutine_check = false;
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 12)
        {
            wall_bound *= -1;
        }
    }
}
