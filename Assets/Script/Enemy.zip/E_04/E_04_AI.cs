using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class E_04_AI : MonoBehaviour
{
    //���Դ޸���
    Vector2 dir;
    private Quaternion rotation;
    public GameObject Attackrange;
    public float attack_time;
    bool attack_status;
    public bool can_attack;
    Vector3 player_transform_buffer;
    public float tr_buffertime=0.25f;
    float tr_buffertimer = 0;
    float attack_weight;
    Unit unit;
    GameObject Player;
    Enemy_status E_Status;
    float move_distance;
    public float move_distance_max;
    public float enemy_size_x;
    public float enemy_size_y;
    public float moving_buffer;
    float moving_weight;
    public float range_distance;
    bool move_corutine_check;
    bool idle_corutine_check;
    bool moving_status;
    public float idle_time;

    Collider2D sensitive;

    Animator e_ani;
    // Start is called before the first frame update
    void Start()
    {
        tr_buffertimer = tr_buffertime;
        Player = GameObject.FindGameObjectWithTag("Player");
        unit = this.GetComponent<Unit>();
        attack_status = true;
        e_ani = this.transform.GetChild(1).GetComponent<Animator>();
        E_Status = this.gameObject.GetComponent<Enemy_status>();
        E_Status.set_layout(3);

        unit.max_hp = E_Status.get_max_hp();
        unit.Health_point = E_Status.get_hp();
        unit.Defense_point = E_Status.get_defense_point();
        unit.move_speed = E_Status.get_speed();
        unit.Attack_point = E_Status.get_atk();
    }
    void ray_to_player()
    {
        float length = Mathf.Log(Mathf.Pow(18, 2) + Mathf.Pow(28, 2)) * 2;
        
        Debug.DrawLine(transform.position, Player.transform.position.normalized * range_distance, Color.red);
        // Debug.DrawLine(transform.position - Vector3.up * (bullet_size / 2), Player.transform.position.normalized * range_distance, Color.red);
        // var ray1= Physics2D.Raycast(transform.position+Vector3.up*(bullet_size/2), dir, length, LayerMask.GetMask("platform_can't_pass"));
        // var ray2 = Physics2D.Raycast(transform.position - Vector3.up * (bullet_size / 2), dir, length, LayerMask.GetMask("platform_can't_pass"));
        var ray = Physics2D.Raycast(transform.position, dir, length, LayerMask.GetMask("platform_can't_pass"));
        var ray2 = Physics2D.Raycast(transform.position, dir, length, LayerMask.GetMask("platform_can_pass"));
        if (ray.collider != null)
        {
          
            can_attack = false;
        }
        else
        {
       
            can_attack = true;
        }
    }
    // Update is called once per frame
    void Update()
    {
        brain();
    }
    void brain()//ai ����
    {
       
        if (unit.Health_point > 0)
        {
            tr_buffertimer -= Time.deltaTime;
            if (tr_buffertimer <= 0)
            {
                player_transform_buffer = Player.transform.position;
            }
            dir = player_transform_buffer - this.transform.position;
            var dir_dist = Mathf.Log(Mathf.Pow(dir.x, 2) + (Mathf.Pow(dir.y, 2)));
            ray_to_player();
            var sentinal_ray_1= Physics2D.Raycast(transform.position, Vector3.left, 15, LayerMask.GetMask("Player"));
            var sentinal_ray_2 = Physics2D.Raycast(transform.position +Vector3.up* enemy_size_y/3, Vector3.left, 15, LayerMask.GetMask("Player"));
            var sentinal_ray_3 = Physics2D.Raycast(transform.position + Vector3.up * enemy_size_y / 3*2, Vector3.left, 15, LayerMask.GetMask("Player"));
            Debug.DrawLine(transform.position + Vector3.up * enemy_size_y, transform.position + Vector3.up * enemy_size_y+ Vector3.left*15, Color.red);
            if (sentinal_ray_1.collider != null || sentinal_ray_2.collider != null || sentinal_ray_3.collider != null)
            {
                unit.sentinal = true;
            }
            
            if ( unit.sentinal)//���� �ȸ���+�����Ÿ���
            {
                attack_ai_0();
            }
            else
            {
                e_ani.SetBool("Attack 0", false);
                if (move_corutine_check)
                {
                    if (!moving_status)
                        StartCoroutine("move");//�̵�����
                }
                else
                {
                    if (!idle_corutine_check)
                        StartCoroutine("idle");//���  ����
                }
                if (moving_status)
                {
                    move_ai_0();
                }
            }
        }
        else
        {
            die();
        }
    }

    void die()
    {
        unit.HpCheack();
        
    }





    public void attack_range_on()
    {
        Attackrange.SetActive(true);
    }

    public void attack_range_off()
    {
        Attackrange.SetActive(false);
    }








    void move_ai_0()
    {

        transform.Translate(Vector3.left*unit.direction * unit.move_speed * Time.deltaTime);//�������� ������
   
        move_distance += unit.move_speed * Time.deltaTime;
        //���鿡 ����ĳ��Ʈ�� ������
        Debug.DrawLine(transform.position, transform.position - (new Vector3(0.2f, 0, 0) + new Vector3(enemy_size_x / 1.5f, 0, 0)) * unit.direction, Color.green);
        var wall_ray = Physics2D.Raycast(transform.position, Vector3.left * unit.direction, enemy_size_x / 1.5f + 0.4f, LayerMask.GetMask("platform_can't_pass"));
        if (wall_ray.collider != null)
        {
            unit.direction_change_spr();
            move_distance = 0;
        }
        
        //�տ� �÷����� ������ ���� �ٲ�
        var bottom_ray = Physics2D.Raycast(transform.position + Vector3.left * (enemy_size_x / 2) * unit.direction, Vector3.down, enemy_size_y / 2 + 0.4f, LayerMask.GetMask("platform_can't_pass"));
        var bottom_ray_2 = Physics2D.Raycast(transform.position + Vector3.left * (enemy_size_x / 2) * unit.direction, Vector3.down, enemy_size_y / 2 + 0.4f, LayerMask.GetMask("platform_can_pass"));
        Debug.DrawLine(transform.position + Vector3.left * (enemy_size_x / 2) * unit.direction, transform.position + Vector3.left * (enemy_size_x / 2) * unit.direction + (Vector3.down * (enemy_size_y / 2) + new Vector3(0, 0.4f)), Color.blue);
        if (bottom_ray.collider == null && bottom_ray_2.collider == null)
        {
            unit.direction_change_spr();
            move_distance = 0;
        }

    }
    void attack_ai_0()
    {
        e_ani.SetBool("Walk", false);
        e_ani.SetBool("Attack 0", true);
        var sentinal_ray_1 = Physics2D.Raycast(transform.position, Vector3.right, 15, LayerMask.GetMask("Player"));
        var sentinal_ray_2 = Physics2D.Raycast(transform.position + Vector3.up * enemy_size_y / 3, Vector3.right, 15, LayerMask.GetMask("Player"));
        var sentinal_ray_3 = Physics2D.Raycast(transform.position + Vector3.up * enemy_size_y / 3 * 2, Vector3.right, 15, LayerMask.GetMask("Player"));
        if (sentinal_ray_1.collider != null || sentinal_ray_2.collider != null || sentinal_ray_3.collider != null)
        {

            transform.Translate(Vector3.left * unit.move_speed * 1.5f * Time.deltaTime);//�������� ������
            if (unit.direction == 1)
            {
                if (dir.x >= 0)
                {
                    unit.direction_change_spr();
                }
            }
            else
            {
                if (dir.x < 0)
                {
                    unit.direction_change_spr();
                }
            }
            var wall_ray = Physics2D.Raycast(transform.position, Vector3.right * unit.direction, enemy_size_x / 2 + 0.2f, LayerMask.GetMask("platform_can't_pass"));
            if (wall_ray.collider != null)
            {
                Debug.DrawLine(transform.position, transform.position + (new Vector3(0.2f, 0, 0) + new Vector3(enemy_size_x / 2, 0, 0)) * unit.direction, Color.green);
                unit.direction_change_spr();
                move_distance = 0;
            }
        }
        else 
        
        {

            transform.Translate(Vector3.left * unit.move_speed * 1.5f * Time.deltaTime);//�������� ������

            var wall_ray = Physics2D.Raycast(transform.position, Vector3.left * unit.direction, enemy_size_x / 2 + 0.2f, LayerMask.GetMask("platform_can't_pass"));
            if (wall_ray.collider != null)
            {
                Debug.DrawLine(transform.position, transform.position + (new Vector3(0.2f, 0, 0) + new Vector3(enemy_size_x / 2, 0, 0)) * unit.direction, Color.green);
                unit.direction_change_spr();
                move_distance = 0;
            }
        }
    }

    
    IEnumerator move()
    {
        var wait = new WaitForSeconds(moving_buffer + moving_weight);
        e_ani.SetBool("Walk", true);
        moving_status = true;
        yield return wait;
        e_ani.SetBool("Walk", false);
        move_corutine_check = false;
        moving_status = false;
        moving_weight = Random.Range(-1, 1);
    }
    IEnumerator idle()
    {
        var wait = new WaitForSeconds(idle_time);
        e_ani.SetBool("Walk", false);
        idle_corutine_check = true;
        yield return wait;
        move_corutine_check = true;
        idle_corutine_check = false;
    }

}


