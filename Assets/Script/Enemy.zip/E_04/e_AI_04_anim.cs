using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class e_AI_04_anim : MonoBehaviour
{
    E_04_AI e_04;
    // Start is called before the first frame update
    void Start()
    {
        e_04 = this.transform.parent.GetComponent<E_04_AI>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void attack_range_on()
    {
        e_04.attack_range_on();
    }
    void attack_range_off()
    {
        e_04.attack_range_off();
    }
}
